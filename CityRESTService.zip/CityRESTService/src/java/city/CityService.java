package city;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/city")
public class CityService {

    public Connection getConnection(){

        Connection con=null;

        try{

            Class.forName("com.mysql.cj.jdbc.Driver");

            con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/citydb",
                    "root",
                    ""
            );

        }

        catch(Exception e){
            e.printStackTrace();
        }

        return con;
    }

    // ADD CITY
    @GET
    @Path("/add/{id}/{name}/{district}/{population}")
    @Produces(MediaType.TEXT_HTML)
    public String addCity(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("name") String name,
            @javax.ws.rs.PathParam("district") String district,
            @javax.ws.rs.PathParam("population") int population){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "insert into city values(?,?,?,?)"
            );

            ps.setInt(1,id);
            ps.setString(2,name);
            ps.setString(3,district);
            ps.setInt(4,population);

            ps.executeUpdate();

            return "City Added Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // GET CITY
    @GET
    @Path("/get/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String getCity(@javax.ws.rs.PathParam("id") int id){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "select * from city where id=?"
            );

            ps.setInt(1,id);

            ResultSet rs=ps.executeQuery();

            if(rs.next()){

                return "City : "
                        +rs.getString("City_Name")+" "
                        +rs.getString("District_Name")+" "
                        +rs.getInt("Population");

            }

            else{

                return "City Not Found";

            }

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // UPDATE POPULATION
    @GET
    @Path("/update/{id}/{population}")
    @Produces(MediaType.TEXT_HTML)
    public String updateCity(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("population") int population){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "update city set Population=? where id=?"
            );

            ps.setInt(1,population);
            ps.setInt(2,id);

            ps.executeUpdate();

            return "City Population Updated";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // DELETE CITY
    @GET
    @Path("/delete/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String deleteCity(@javax.ws.rs.PathParam("id") int id){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "delete from city where id=?"
            );

            ps.setInt(1,id);

            ps.executeUpdate();

            return "City Deleted";

        }

        catch(Exception e){
            return e.toString();
        }
    }

}