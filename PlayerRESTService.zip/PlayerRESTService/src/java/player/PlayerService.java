package player;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/player")
public class PlayerService {

    public Connection getConnection(){

        Connection con=null;

        try{

            Class.forName("com.mysql.cj.jdbc.Driver");

            con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/playerdb",
                    "root",
                    ""
            );

        }

        catch(Exception e){
            e.printStackTrace();
        }

        return con;
    }

    // ADD PLAYER
    @GET
    @Path("/add/{id}/{name}/{age}/{country}/{runs}")
    @Produces(MediaType.TEXT_HTML)
    public String addPlayer(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("name") String name,
            @javax.ws.rs.PathParam("age") int age,
            @javax.ws.rs.PathParam("country") String country,
            @javax.ws.rs.PathParam("runs") int runs){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "insert into player values(?,?,?,?,?)"
            );

            ps.setInt(1,id);
            ps.setString(2,name);
            ps.setInt(3,age);
            ps.setString(4,country);
            ps.setInt(5,runs);

            ps.executeUpdate();

            return "Player Added Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // GET PLAYER
    @GET
    @Path("/get/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String getPlayer(@javax.ws.rs.PathParam("id") int id){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "select * from player where id=?"
            );

            ps.setInt(1,id);

            ResultSet rs=ps.executeQuery();

            if(rs.next()){

                return "Player : "
                        +rs.getString("Player_Name")+" "
                        +rs.getInt("age")+" "
                        +rs.getString("Country")+" "
                        +rs.getInt("Runs");

            }

            else{

                return "Player Not Found";

            }

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // UPDATE RUNS
    @GET
    @Path("/update/{id}/{runs}")
    @Produces(MediaType.TEXT_HTML)
    public String updatePlayer(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("runs") int runs){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "update player set Runs=? where id=?"
            );

            ps.setInt(1,runs);
            ps.setInt(2,id);

            ps.executeUpdate();

            return "Player Runs Updated";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // DELETE PLAYER
    @GET
    @Path("/delete/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String deletePlayer(@javax.ws.rs.PathParam("id") int id){

        try{

            Connection con=getConnection();

            PreparedStatement ps=con.prepareStatement(
                    "delete from player where id=?"
            );

            ps.setInt(1,id);

            ps.executeUpdate();

            return "Player Deleted";

        }

        catch(Exception e){
            return e.toString();
        }
    }

}