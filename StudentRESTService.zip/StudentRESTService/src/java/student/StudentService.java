package student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/student")
public class StudentService {

    public Connection getConnection(){

        Connection con=null;

        try{

        Class.forName("com.mysql.cj.jdbc.Driver");

        con=DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/studentdb",
        "root",
        "");

        }

        catch(Exception e){
            e.printStackTrace();
        }

        return con;
    }

    // ADD
    @GET
    @Path("/add/{id}/{name}/{age}/{phone}/{subject}")
    @Produces(MediaType.TEXT_HTML)
    public String addStudent(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("name") String name,
            @javax.ws.rs.PathParam("age") int age,
            @javax.ws.rs.PathParam("phone") String phone,
            @javax.ws.rs.PathParam("subject") String subject){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "insert into student(id,Student_Name,age,Phone_no,Subject) values(?,?,?,?,?)");

        ps.setInt(1,id);
        ps.setString(2,name);
        ps.setInt(3,age);
        ps.setString(4,phone);
        ps.setString(5,subject);

        ps.executeUpdate();

        return "Student Added Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // GET
    @GET
    @Path("/get/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String getStudent(@javax.ws.rs.PathParam("id") int id){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "select * from student where id=?");

        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next()){

        return "Student : "
        +rs.getString("Student_Name")+" "
        +rs.getInt("age")+" "
        +rs.getString("Phone_no")+" "
        +rs.getString("Subject");

        }

        else{

        return "Student Not Found";

        }

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // UPDATE
    @GET
    @Path("/update/{id}/{subject}")
    @Produces(MediaType.TEXT_HTML)
    public String updateStudent(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("subject") String subject){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "update student set Subject=? where id=?");

        ps.setString(1,subject);
        ps.setInt(2,id);

        ps.executeUpdate();

        return "Student Updated Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // DELETE
    @GET
    @Path("/delete/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String deleteStudent(@javax.ws.rs.PathParam("id") int id){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "delete from student where id=?");

        ps.setInt(1,id);

        ps.executeUpdate();

        return "Student Deleted Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

}