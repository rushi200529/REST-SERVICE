package employee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/employee")
public class EmployeeService {

    public Connection getConnection(){

        Connection con=null;

        try{

        Class.forName("com.mysql.cj.jdbc.Driver");

        con=DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/employeedb",
        "root",
        "");

        }

        catch(Exception e){
            e.printStackTrace();
        }

        return con;
    }

    // ADD
    @GET
    @Path("/add/{id}/{name}/{age}/{phone}/{department}")
    @Produces(MediaType.TEXT_HTML)
    public String addEmployee(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("name") String name,
            @javax.ws.rs.PathParam("age") int age,
            @javax.ws.rs.PathParam("phone") String phone,
            @javax.ws.rs.PathParam("department") String department){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "insert into employee(id,Employee_Name,age,Phone_no,Department) values(?,?,?,?,?)");

        ps.setInt(1,id);
        ps.setString(2,name);
        ps.setInt(3,age);
        ps.setString(4,phone);
        ps.setString(5,department);

        ps.executeUpdate();

        return "Employee Added Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // GET
    @GET
    @Path("/get/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String getEmployee(@javax.ws.rs.PathParam("id") int id){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "select * from employee where id=?");

        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next()){

        return "Employee : "
        +rs.getString("Employee_Name")+" "
        +rs.getInt("age")+" "
        +rs.getString("Phone_no")+" "
        +rs.getString("Department");

        }

        else{

        return "Employee Not Found";

        }

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // UPDATE
    @GET
    @Path("/update/{id}/{department}")
    @Produces(MediaType.TEXT_HTML)
    public String updateEmployee(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("department") String department){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "update employee set Department=? where id=?");

        ps.setString(1,department);
        ps.setInt(2,id);

        ps.executeUpdate();

        return "Employee Updated Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // DELETE
    @GET
    @Path("/delete/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String deleteEmployee(@javax.ws.rs.PathParam("id") int id){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "delete from employee where id=?");

        ps.setInt(1,id);

        ps.executeUpdate();

        return "Employee Deleted Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

}