package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/product")
public class ProductService {

    public Connection getConnection(){

        Connection con=null;

        try{

        Class.forName("com.mysql.cj.jdbc.Driver");

        con=DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/productdb",
        "root",
        "");

        }

        catch(Exception e){
            e.printStackTrace();
        }

        return con;
    }

    // ADD
    @GET
    @Path("/add/{id}/{name}/{qty}/{date}")
    @Produces(MediaType.TEXT_HTML)
    public String addProduct(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("name") String name,
            @javax.ws.rs.PathParam("qty") int qty,
            @javax.ws.rs.PathParam("date") String date){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "insert into product(id,Product_Name,Quantity,Expiry_date) values(?,?,?,?)");

        ps.setInt(1,id);
        ps.setString(2,name);
        ps.setInt(3,qty);
        ps.setString(4,date);

        ps.executeUpdate();

        return "Product Added Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // GET
    @GET
    @Path("/get/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String getProduct(@javax.ws.rs.PathParam("id") int id){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "select * from product where id=?");

        ps.setInt(1,id);

        ResultSet rs=ps.executeQuery();

        if(rs.next()){

        return "Product : "
        +rs.getString("Product_Name")+" "
        +rs.getInt("Quantity")+" "
        +rs.getString("Expiry_date");

        }

        else{

        return "Product Not Found";

        }

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // UPDATE
    @GET
    @Path("/update/{id}/{qty}")
    @Produces(MediaType.TEXT_HTML)
    public String updateProduct(
            @javax.ws.rs.PathParam("id") int id,
            @javax.ws.rs.PathParam("qty") int qty){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "update product set Quantity=? where id=?");

        ps.setInt(1,qty);
        ps.setInt(2,id);

        ps.executeUpdate();

        return "Product Updated Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

    // DELETE
    @GET
    @Path("/delete/{id}")
    @Produces(MediaType.TEXT_HTML)
    public String deleteProduct(@javax.ws.rs.PathParam("id") int id){

        try{

        Connection con=getConnection();

        PreparedStatement ps=con.prepareStatement(
        "delete from product where id=?");

        ps.setInt(1,id);

        ps.executeUpdate();

        return "Product Deleted Successfully";

        }

        catch(Exception e){
            return e.toString();
        }
    }

}